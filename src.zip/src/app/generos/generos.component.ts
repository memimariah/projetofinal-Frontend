import { Component } from '@angular/core';

@Component({
  selector: 'app-generos',
  imports: [],
  templateUrl: './generos.component.html',
  styleUrl: './generos.component.css'
})
export class GenerosComponent {

}
