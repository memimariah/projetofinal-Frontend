import { Component } from '@angular/core';

@Component({
  selector: 'app-lancamentos',
  imports: [],
  templateUrl: './lancamentos.component.html',
  styleUrl: './lancamentos.component.css'
})
export class LancamentosComponent {

}
